var assert = require('chai').assert;
var Nav = require('../components/Nav.jsx');

describe('Sanity Check', function () {
	it('should be able to run mocha and use chai for assertions, and import JSX', function () {
		assert.ok(true);
	});
});
